import { ApplicationConfig, provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';

import { routes } from './app.routes';

// HTTP interceptors (e.g. attaching the auth token, handling 401 responses)
// will be added here once core/interceptors is populated in Phase A/B
// (see core/interceptors/README.md).
export const appConfig: ApplicationConfig = {
  providers: [
    provideZonelessChangeDetection(),
    provideRouter(routes),
    provideHttpClient(withInterceptors([])),
  ],
};
