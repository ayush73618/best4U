# shared/components

Reusable, feature-agnostic UI: Modal, Toast, Button, Card, Input,
EmptyState, LoadingSpinner — replacing the React app's `utilities/`
components (Modal.js, Notification.js, CartIcon.js).

**Next up:** build these once the design tokens in `src/assets/styles` are
decided (Section 17 — one shared design system, not one look per module).
