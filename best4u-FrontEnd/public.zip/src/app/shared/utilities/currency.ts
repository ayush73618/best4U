// Indian Rupee, Indian digit grouping (lakhs/crores) — every BM4U
// calculator is India-centric, so this is the one shared formatter
// instead of five copies of the same Intl.NumberFormat config.
const CURRENCY_FORMAT = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});

export function formatINR(value: number): string {
  return CURRENCY_FORMAT.format(value);
}