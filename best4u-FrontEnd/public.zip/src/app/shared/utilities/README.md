# shared/utilities

Plain TypeScript helpers with no Angular dependency: validators,
formatters, small pure functions reused across features.
