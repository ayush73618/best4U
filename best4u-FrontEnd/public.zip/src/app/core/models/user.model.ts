// Mirrors the backend User entity — including the `roles` field that
// doesn't exist on the entity yet today but is part of the agreed backend
// fix (Track A, Step 1). Update this once the real API contract is written.
export interface User {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  mobileNumber: string;
  roles: string[];
}
