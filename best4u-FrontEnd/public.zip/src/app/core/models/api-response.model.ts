// Mirrors the backend's response envelope (currently com.best4u.domain.dto.Best4UResponse,
// to be renamed ApiResponse during the backend consolidation — see the agreed
// Track A plan). Keep this in sync with whatever the API contract (Step 3) settles on.
export interface ApiResponse<T> {
  status: number;
  message: string;
  data: T;
}
