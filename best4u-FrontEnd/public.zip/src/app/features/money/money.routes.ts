import { Routes } from '@angular/router';

// Same pattern as tools.routes.ts — one tool so far, routes straight to it.
export const MONEY_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./emi-calculator/emi-calculator').then((m) => m.EmiCalculator),
  },
];