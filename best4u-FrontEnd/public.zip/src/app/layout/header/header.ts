import { Component } from '@angular/core';

// Replaces React's Navbar.js. Search is intentionally a disabled placeholder
// here — platform/search doesn't exist yet, and a fake-looking search box
// that silently does nothing would be worse than an honestly disabled one.
@Component({
  selector: 'app-header',
  standalone: true,
  templateUrl: './header.html',
  styleUrl: './header.scss',
})
export class Header {}