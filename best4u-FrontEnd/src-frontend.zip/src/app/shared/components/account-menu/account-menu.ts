import {
  Component,
  ElementRef,
  HostListener,
  inject,
  signal,
} from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { RouterLink } from "@angular/router";
import { environment } from "../../../../environments/environment";
import { ApiResponse } from "../../../core/models/api-response.model";
import { AuthService } from "../../../core/auth/auth.service";
import { FADE_IN } from "../../../animations";

@Component({
  selector: "app-account-menu",
  standalone: true,
  imports: [RouterLink],
  templateUrl: "./account-menu.html",
  styleUrl: "./account-menu.scss",
  animations: [FADE_IN],
})
export class AccountMenu {
  protected readonly authService = inject(AuthService);
  private readonly http = inject(HttpClient);
  private readonly elementRef = inject(ElementRef);

  protected readonly isOpen = signal(false);
  protected readonly applying = signal(false);

  protected get isAdmin(): boolean {
    return this.authService.currentUser()?.roles.includes("ADMIN") ?? false;
  }

  protected toggle(): void {
    this.isOpen.update((v) => !v);
  }

  protected close(): void {
    this.isOpen.set(false);
  }

  @HostListener("document:click", ["$event"])
  onDocumentClick(event: MouseEvent): void {
    if (!this.elementRef.nativeElement.contains(event.target)) this.close();
  }

  protected applyForSeller(): void {
    this.applying.set(true);
    this.http
      .post<
        ApiResponse<void>
      >(`${environment.apiBaseUrl}/auth/apply-seller`, {})
      .subscribe({
        next: () => {
          this.applying.set(false);
          this.authService.markSellerApplicationPending();
        },
        error: () => this.applying.set(false),
      });
  }

  protected logout(): void {
    this.close();
    this.authService.logout();
  }
}
